# Scratch Link digital certificates

The certificates to be used for WSS communication should be placed here. These certificates are not to be committed
into the repository.

See `convert-certificates.sh` for details on preparing certificates for both Mac and Windows.
