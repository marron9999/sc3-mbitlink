using System;
using System.Windows.Forms;


namespace scratch_link
{

    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            App app = new App(args);
            Application.Run(app);
        }
    }
}


